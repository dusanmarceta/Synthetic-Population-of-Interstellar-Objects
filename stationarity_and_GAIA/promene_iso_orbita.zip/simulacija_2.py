import numpy as np
import rebound
import time
import matplotlib.pyplot as plt

# ovo sam dodao jer sam imao neku network grešku
import rebound.horizons
rebound.horizons.SSL_CONTEXT = 'unverified'

# Ulazni podaci
korak = 1/365 # korak u godinama
Time = 10 # ukupno vreme u godinama
epoha = "JD2456200.5000" # pocetna epoha (ovo nije vazno jer mi generisemo populaciju ISOs za proizvoljnu epohu)

#---------------------------------------


sim=rebound.Simulation()
#sim.exit_min_distance = 0.1

# dinamicki model
sim.add("Sun", date=epoha)
sim.particles[0].m=sim.particles[0].m+1.6601141530543488e-07 # Dodavanje mase Merkura na Sunce
sim.add("venus", date=epoha)
sim.add("earth", date=epoha)
sim.add("mars", date=epoha)
sim.add("jupiter", date=epoha)
sim.add("saturn", date=epoha)
sim.add("uran", date=epoha)
sim.add("neptun", date=epoha)

sim.move_to_com()        # We always move to the center of momentum frame before an integration


# stavljamo broj aktivnih tela cija se gravitacija uzima u obzir. Ako ovo ne stavimo on racuna
# interakciju izmedju svaka dva asterida iako im je masa jednaka nuli
sim.N_active = 8 

# vrsta integratora (svaki ima svoju svrhu, za sada neka stoji ovaj)
sim.integrator = "ias15"
#sim.integrator = "whfast"

# izbacili smo asteroide i sada umesto njih učitavamo ISO orbite
iso_orbits = np.loadtxt('iso_orbits.txt', skiprows=1)[:50] 
for orbit in iso_orbits:
    sim.add(primary=sim.particles[0], a=orbit[0], e=orbit[1], inc=np.deg2rad(orbit[2]), 
            Omega=np.deg2rad(orbit[3]), omega=np.deg2rad(orbit[4]), f=np.deg2rad(orbit[5])) 


year = 2.*np.pi # One year in units where G=1 (u sistemu jedinica koje koristi Rebound 2 pi je jedna godina)
times = np.arange(0.,Time*year, korak*year) # vremenski trenuci u kojima hocemo izlazne rezultate
elements = np.zeros((len(sim.particles), len(times), 5)) # niz u koji cemo stavljati orbitalne elemente asteroida


from tqdm import tqdm
for i, t in enumerate(tqdm(times, desc="Integrating orbits")):
    # sim.integrate(t)
    try:
        sim.integrate(t)

    except rebound.Encounter as error:
        print(t/np.pi/2, error)
        

    # konvertuje x, y, z, vx, vy, vz u orbitalne elemente
    for j in range(sim.N_active, len(sim.particles)): # ne racunamo za planete, pa zato ide od sim.N_active
            #orb = sim.particles[j].orbit(primary=sim.particles[0]) # heliocentrični sistem
            orb = sim.particles[j].orbit() # baricentrični sistem
            elements[j][i][:] = [orb.a, orb.e, np.rad2deg(orb.inc), np.rad2deg(orb.Omega), np.rad2deg(orb.omega)] # ubacujemo u niz


plt.plot(np.transpose(elements[9])[0]*(1-np.transpose(elements[9])[1])) # plot perihelskog rastojanja desetog tela (uključujući prvih osam velikih tela) kroz vreme
plt.show()

# todo: pronaći maksimalnu promenu perihelskog rastojanja i elemenata; proveriti da li negde e pada ispod 1